/*
 *           C#Like
 * Copyright © 2022-2023 RongRong. All right reserved.
 */
using System;
using System.Collections.Generic;
using UnityEngine;

namespace CSharpLike
{
    /// <summary>
    /// Example test C# function in hot update script.
    /// </summary>
    public partial class SampleCSharp : LikeBehaviour
    {
        /// <summary>
        /// for foreach continue break if-else return while do-while switch-case-default.
        /// All can be mixed together.
        /// </summary>
        void TestLoop()
        {
            Debug.LogError("Test Loop:");
            int x = 1;
            int y = 3;
            int z = 100;

            //test if-else
            if (x < y)
                Debug.Log("test 'if-else': enter 'if'");
            else if (x < z)
                Debug.Log("test 'if-else': enter 'else if'");
            else
                Debug.Log("test 'if-else': enter 'else'");

            List<int> ints = new List<int>();
            ints.Add(1);
            ints.Add(2);
            ints.Add(3);
            //test for
            for (int i = 0, j = 2; i < ints.Count; i++, j += i)
            {
                if (i == 2)
                {
                    Debug.Log("test 'continue':");
                    continue;
                }
                Debug.Log("test 'for': ints[" + i + "] = " + ints[i] + ",j = " + j);
            }

            //test foreach
            foreach(var item in ints)
            {
                Debug.Log("test 'foreach': item = " + item);
                if (item == 2)
                {
                    Debug.Log("test 'break':");
                    break;
                }
            }

            //test while
            while(x < y)
            {
                x++;
                Debug.Log("test 'while': x = " + x + ", y = " + y);
            }

            //test do-while
            x = 1;
            do
            {
                x++;
                Debug.Log("test 'do-while': x = " + x + ", y = " + y);
            } while (x < y) ;

            //test switch-case-default
            switch(DateTime.Now.DayOfWeek)
            {
                case DayOfWeek.Monday:
                    Debug.Log("test 'switch-case-default': sad because have to work.");
                    break;
                case DayOfWeek.Friday:
                    Debug.Log("test 'switch-case-default': happy because rest day is coming!");
                    break;
                case DayOfWeek.Thursday:
                    {
                        Debug.Log("Do something");
                        Debug.Log("Do something");
                    }
                    break;
                /* You can't do it like this, it not support now
                case DayOfWeek.Thursday:
                    {
                        Debug.Log("Do something");
                        Debug.Log("Do something");
                        break;
                    }
                    //MUST end with 'break/return/yield break/throw' here. Not the '}'
                */
                //Both the Saturday and Sunday use the same code.
                case DayOfWeek.Saturday:
                case DayOfWeek.Sunday:
                    Debug.Log("test 'switch-case-default': exciting because had fun in rest day.");
                    break;
                default:
                    Debug.Log("test 'switch-case-default': work hard. Fighting!");
                    break;
            }
        }
    }
}