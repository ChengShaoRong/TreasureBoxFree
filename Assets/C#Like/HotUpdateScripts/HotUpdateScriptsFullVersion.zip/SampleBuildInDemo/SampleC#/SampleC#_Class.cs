/*
 *           C#Like
 * Copyright © 2022-2023 RongRong. All right reserved.
 */
using UnityEngine;
using CSharpLike.Subclass;

namespace CSharpLike
{
    /// <summary>
    /// Example test C# function in hot update script.
    /// </summary>
    public partial class SampleCSharp : LikeBehaviour
    {
        void TestClass()
        {
            Debug.LogError("Test class:");
            //test class
            Mammals cow = new Mammals(4, 4, "cow");
            Debug.Log("cow:" + cow.GetInfo());
            //test interface
            IAnimal bull = new Mammals(0, 4, "bull");
            bull.female = false;
            Debug.Log("bull:female=" + bull.female + ", CanUseTool=" + bull.CanUseTool());
            Human adam = new Human("Adam", false);//test Constructor
            Debug.Log("adam:" + adam.GetInfo());
            Debug.Log("adam:GetTypeString=" + adam.GetTypeString());
            Debug.Log("adam:GetBaseTypeString=" + adam.GetBaseTypeString());//test 'base' keyword
            Human eve = new Human("Eve");//test Constructor
            Debug.Log("eve:" + eve.GetInfo() + ", CanUseTool=" + eve.CanUseTool());
            //test Destructor
        }
    }
}