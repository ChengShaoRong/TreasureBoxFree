/*
 *           C#Like
 * Copyright © 2022-2023 RongRong. All right reserved.
 */
using System;
using UnityEngine;

namespace CSharpLike
{
    /// <summary>
    /// Example test C# function in hot update script.
    /// </summary>
    public partial class SampleCSharp : LikeBehaviour
    {
        public enum MyWeek : byte
        {
            Sunday, Monday, Tuesday, Wednesday, Thursday, Friday, Saturday
        }
        public enum MyTestEnum //base type is optional,default is ': int'
        {
            MyTestEnum1,//0 //first enum default value is 0
            MyTestEnum2 = 0x5,//5   //test 16bit number
            MyTestEnum3,//6    //default value is last number + 1
            MyTestEnum4 = 7,
            MyTestEnum5 = 7,    //direct set number or math operation, same as native C#
            MyTestEnum6 = MyTestEnum3 * 100,//600   
            MyTestEnum7 = 1 << 10 + MyTestEnum12,//66559
            MyTestEnum8 = MyTestEnum6 & MyTestEnum7,//600
            MyTestEnum9 = MyTestEnum6 | MyTestEnum7,//66559
            MyTestEnum10 = MyTestEnum9 % 100 + (123 + MyTestEnum6 - MyTestEnum2) / 5,//202
            MyTestEnum11 = MyTestEnum7 >> 2,//16639
            MyTestEnum12 = ushort.MaxValue,//65535  //support const value, same as native C#
            MyTestEnum13 = UInt16.MinValue,//0
        }
        void TestEnum()
        {
            Debug.LogError("Test Enum:");
            Debug.Log("Test use the enum of the normal script: DayOfWeek = " + DayOfWeek.Saturday);//output Saturday
            Debug.Log("Test use the enum of the normal script that inside class: TestClassWithEnum.TestEnumInClass.Abc = " + TestClassWithEnum.TestEnumInClass.Abc);//output Abc
            MyWeek myWeek = MyWeek.Saturday;
            //This's the different from native C#.
            //You must be careful if you print the value of enum.
            Debug.Log("Test Enum:MyWeek.Saturday=" + MyWeek.Saturday);//output 6 in hot update mode, but in 'debug mode' is 'Saturday'
            Debug.Log("Test Enum:myWeek=" + myWeek);//output 6 in hot update mode, but in 'debug mode' is 'Saturday'
            //You must use 'HotUpdateManager.ConvertEnumString' to get the string of the value.
            Debug.Log("Test Enum:myWeek=" + HotUpdateManager.ConvertEnumString(typeof(MyWeek), myWeek));//output 'Saturday'
            //You must use 'HotUpdateManager.ConvertEnumNumber' to get the number by string.
            Debug.Log("Test Enum:'Tuesday' number = " + HotUpdateManager.ConvertEnumNumber(typeof(MyWeek), "Tuesday"));//output 2
            int i = 202;
            switch ((MyTestEnum)i)
            {
                case MyTestEnum.MyTestEnum1:
                    Debug.Log("Test Enum in switch:MyTestEnum.MyTestEnum1");
                    break;
                case MyTestEnum.MyTestEnum2:
                    Debug.Log("Test Enum in switch:MyTestEnum.MyTestEnum2");
                    break;
                case MyTestEnum.MyTestEnum3:
                    Debug.Log("Test Enum in switch:MyTestEnum.MyTestEnum3");
                    break;
                case MyTestEnum.MyTestEnum6:
                    Debug.Log("Test Enum in switch:MyTestEnum.MyTestEnum6");
                    break;
                case MyTestEnum.MyTestEnum10:
                    Debug.Log("Test Enum in switch:MyTestEnum.MyTestEnum10");
                    break;
                default:
                    Debug.Log("Test Enum in switch:default");
                    break;
            }
        }
    }
}