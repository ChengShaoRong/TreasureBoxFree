/*
 *           C#Like
 * Copyright © 2022-2023 RongRong. All right reserved.
 */
using UnityEngine;

namespace CSharpLike
{
    /// <summary>
    /// Example test C# function in hot update script.
    /// </summary>
    public partial class SampleCSharp : LikeBehaviour
    {
        /// <summary>
        /// Support unity build-in define symbols and user custom define symbols
        /// ("Edit"->"Project Settings"->"Player"->"Scripting Define Symbols").
        /// just same with unity,except 'UNITY_EDITOR/UNITY_EDITOR_WIN/UNITY_EDITOR_OSX/UNITY_EDITOR_LINUX'
        /// only work both in 'debug mode' and in editor.
        /// </summary>
        void TestMacroAndRegion()
        {
            Debug.LogError("Test Macro:");
#if UNITY_EDITOR 
            Debug.Log("test macro UNITY_EDITOR: in editor and in 'debug mode'");
#else
            Debug.Log("test macro UNITY_EDITOR: not in editor");
#endif

#if UNITY_2018_1_OR_NEWER && (!UNITY_2020_1)
            Debug.Log("Test macro:enter UNITY_2018_1_OR_NEWER && (!UNITY_2020_1)");
    #if UNITY_ANDROID || UNITY_IOS
            Debug.Log("Test macro:enter UNITY_ANDROID || UNITY_IOS");
    #elif UNITY_STANDALONE
            Debug.Log("Test macro:enter UNITY_STANDALONE");
    #endif
#elif UNITY_2017
            Debug.Log("Test macro:enter UNITY_2017");
#else
            Debug.Log("test macro:enter #else");
#endif
            Debug.Log("Test LogError:");
#region Test Region
            Debug.Log("Test Region: content 1");
#endregion
            Debug.Log("Test Region: content 2");
#region Test Region2
            Debug.Log("Test Region: content 3");
#endregion
            Debug.Log("Test Region: content 4");
        }
    }
}