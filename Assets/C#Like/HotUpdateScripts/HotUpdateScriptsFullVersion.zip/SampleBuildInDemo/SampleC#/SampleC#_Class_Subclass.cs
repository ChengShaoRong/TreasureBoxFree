/*
 *           C#Like
 * Copyright © 2022-2023 RongRong. All right reserved.
 */
using UnityEngine;

namespace CSharpLike
{
    /// <summary>
    /// test for class in 'ExampleC#_Class.cs'
    /// </summary>
    namespace Subclass
    {
        public interface IAnimal
        {
            int feet { get; set; }
            bool female { get; set; }
            bool CanUseTool();
        }

        public abstract class Animal : IAnimal//test interface
        {
            public int feet { get; set; }
            public string name;
            public bool female { get; set; }
            public Animal(int feet, string name)
            {
                Debug.Log("Animal(" + feet + "," + name + ")");
                this.feet = feet;
                this.name = name;
                female = true;
            }
            ~Animal()
            {
                Debug.Log("~Animal():" + name);
            }
            public virtual string GetInfo()
            {
                return "Animal:" + name + " with " + feet + " feet. " + clothes;
            }
            public abstract bool CanUseTool();//test 'abstract' keyword
            public virtual string GetTypeString()//test 'virtual' keyword
            {
                return "Animal";
            }
            public virtual string clothes
            {
                get
                {
                    return "naked";
                }
            }
        }

        public class Mammals : Animal
        {
            public int breasts;
            public Mammals(int breasts, int feet, string name)
                : base(feet, name)
            {
                Debug.Log("Mammals(" + breasts + "," + feet + "," + name + ")");
                this.breasts = breasts;
            }

            ~Mammals()
            {
                Debug.Log("~Mammals():" + name);
            }
            public override string GetInfo()
            {
                return "Mammals:" + name + " with " + feet + " feet and "
                    + breasts + " breasts," + clothes;
            }
            public override bool CanUseTool()
            {
                return false;
            }
            public override string GetTypeString()
            {
                return "Mammals";
            }
        }

        public class Human : Mammals
        {
            public Human(string name, bool female)//test Constructor
                : base(2, 2, name)//test 'base' keyword in Constructor
            {
                Debug.Log("Human(" + name + "," + female + ")");
                this.female = female;//test 'this' keyword
            }
            public Human(string name)//test Constructor
                : this(name, true)//test 'this' keyword in Constructor
            {
                Debug.Log("Human(" + name + ")");
            }
            ~Human()//test Destructor
            {
                Debug.Log("~Human():" + name);
            }
            public override string GetInfo()
            {
                return "Human:" + name + " with " + feet + " feet and " + breasts
                    + " breasts, and female = " + female + "," + clothes;
            }
            public override bool CanUseTool()//test 'override' keyword
            {
                return true;
            }
            public override string GetTypeString()
            {
                return "Human";
            }
            public string GetBaseTypeString()
            {
                return base.GetTypeString();//test 'base' keyword
            }
            public override string clothes
            {
                get
                {
                    return female ? "dress" : "suit";//test custom 'get/set' accessor
                }
            }
        }
    }
    /// <summary>
    /// test for namespace in 'ExampleC#_UsingAndNamespace.cs'
    /// </summary>
    namespace SubclassEx
    {
        /// <summary>
        /// this's test namespace with CSharpLike.Subclass.Mammals
        /// </summary>
        public class Mammals
        {
            public int breasts = 2;
            public int eyes = 2;
            public string TestNameSpace()
            {
                return "Mammals:breasts:" + breasts + ", eyes:" + eyes;
            }
        }
        public class Toys
        {
            public string name;
            public Toys(string name)
            {
                this.name = name;
            }
        }
    }
    /// <summary>
    /// test for namespace in 'ExampleC#_UsingAndNamespace.cs'
    /// </summary>
    namespace SubclassEx2
    {
        public class TestNamespace
        {
            public static string GetTestString()
            {
                return "Test string for namespace";
            }
        }
    }
}