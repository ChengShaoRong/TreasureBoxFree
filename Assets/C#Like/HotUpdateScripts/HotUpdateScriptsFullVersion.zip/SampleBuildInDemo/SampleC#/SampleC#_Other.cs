/*
 *           C#Like
 * Copyright © 2022-2023 RongRong. All right reserved.
 */
using System.Collections.Generic;
using UnityEngine;

namespace CSharpLike
{
    /// <summary>
    /// Example test C# function in hot update script.
    /// </summary>
    public partial class SampleCSharp : LikeBehaviour
    {
        /// <summary>
        /// Test other.
        /// </summary>
        void TestOther()
        {
            Debug.LogError("Test Other:");
            //Test use object initializers
            TestObjectInitializer objctInitializer = new TestObjectInitializer()//"()" can be omitted
            {
                a = 1,
                b = "abcd",//You can keep the ',' at the tail or remove it as you like
            };
            Debug.Log($"Test use object initializers: a={objctInitializer.a}, b={objctInitializer.b}");//output a=1, b=abcd

            // Test expression body for constructors and methods and properties and accessors
            TestClassExpression tce = new TestClassExpression(1);
            Debug.Log("Test expression body for constructors: " + tce._Age);//output 1
            Debug.Log("Test expression body for properties: " + tce.Age);//output 1
            Debug.Log("Test expression body for methods: " + tce.GetAge());//output 1
            tce.AgeEx = 2;
            Debug.Log("Test expression body for accessors: " + tce.AgeEx);//output 2

            // Test inline variable declaration
            Dictionary<int, int> dics = new Dictionary<int, int>
            {
                [1] = 2,
                [2] = 3
            };
            if (dics.TryGetValue(1, out int dicValue))
                Debug.Log("Test inline variable declaration: " + dicValue);//output 2

            // Test switch expression
            int x = 1;
            string y = ((x + 1) switch
            {
                0 => "is 0",
                1 => "is 1",
                _ => "is default",
            });
            /*The above expression equal to this
            string y;
            switch (x+1)
            {
                case 0:
                    y = "is 0";
                    break;
                case 1:
                    y = "is 1";
                    break;
                default:
                    y = "is default";
                    break;
            });*/
            Debug.Log("Test switch expression: " + y);//output is default
            Debug.Log("Test switch expression: " + Test(1));//output is 1

            // Test discard '_'
            _ = Test(0);
            Debug.Log("Test switch discard '_': ");
        }
        public string Test(int x)
        {
            return x switch
            {
                0 => "is 0",
                1 => "is 1",
                _ => "is default"
            };
        }
        /*The above 'Test(int x)' equal to this
        public string Test(int x)
        {
            switch (x)
            {
                case 0: return "is 0";
                case 1: return "is 1";
                default: return "is default";
            };
        }*/
        class TestClassExpression
        {
            public int _Age;
            /// <summary>
            /// Test expression body for constructors
            /// </summary>
            public TestClassExpression(int age) => _Age = age;
            /// <summary>
            /// Test expression body for methods
            /// </summary>
            public int GetAge() => _Age;
            /// <summary>
            /// Test expression body for properties
            /// </summary>
            public int Age => _Age;
            /// <summary>
            /// Test expression body for accessors
            /// </summary>
            public int AgeEx { get => _Age; set => _Age = value; }
        }
        /// <summary>
        /// Test use object initializers
        /// </summary>
        public class TestObjectInitializer
        {
            public int a;
            public string b;
        }
    }
}