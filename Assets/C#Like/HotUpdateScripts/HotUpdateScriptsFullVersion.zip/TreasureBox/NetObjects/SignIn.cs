//It's automatic generate by SignIn.ridl.
//You can custom this class, such as override the virtual function in class SignIn_Base, but DON'T modify 'SignIn_Base.cs'.
using System;
using System.Collections.Generic;
using TreasureBox;
using UnityEngine;

namespace CSharpLike
{
	public class SignIn : SignIn_Base
	{
		#region Event for property value changed
		public override void OnChanged()
		{
			mSignInDays = null;
		}
		#endregion //Event for property value changed
		[KissJsonDontSerialize]
		List<int> mSignInDays = null;
		[KissJsonDontSerialize]
		public List<int> SignInDays
        {
			get
            {
				if (mSignInDays == null)
					mSignInDays = Global.StringToList(signInList);
				return mSignInDays;
            }
		}
		[KissJsonDontSerialize]
		public bool ShowSpot => (!SignInDays.Contains(DateTime.Now.Day));
	}
}
