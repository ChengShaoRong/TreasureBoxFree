//It's automatic generate by 'KissEditor', DON'T modify this file.
//You should modify 'SignIn.cs' or edit by 'KissEditor'.
using System;
using System.Collections.Generic;
using UnityEngine;

namespace CSharpLike
{
	public class SignIn_Base
	{
		public int acctId;
		public int month;
		public string signInList;
		public static SignIn ToSignIn(JSONData jsonData)
		{
			return (SignIn)KissJson.ToObject(typeof(SignIn), jsonData);
		}
		public static List<SignIn> ToSignIns(JSONData jsonData)
		{
			List<object> objs = KissJson.ToObjects(typeof(SignIn), jsonData);
			List<SignIn> signIns = new List<SignIn>();
			foreach (object obj in objs)
				signIns.Add((SignIn)obj);
			return signIns;
		}

		public override string ToString()
		{
			return KissJson.ToJSONData(this).ToJson(true);
		}
		public void Clear()
		{
			KissJson.ClearCache(_uid_);
		}
		string _uid_ = "";
		ulong _sendMask_ = 0;
		public virtual void OnChanged() {}
		public virtual void OnAcctIdChanged(){}
		public virtual void OnMonthChanged(){}
		public virtual void OnSignInListChanged(){}
		public virtual void OnDeleted(){}
		public void NotifyValuesChanged()
		{
			if ((_sendMask_ & 1) > 0) OnAcctIdChanged();
			if ((_sendMask_ & 2) > 0) OnMonthChanged();
			if ((_sendMask_ & 4) > 0) OnSignInListChanged();
			if (_sendMask_ > 0) OnChanged();
		}
	}
}
