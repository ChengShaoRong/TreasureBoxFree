//It's automatic generate by Mail.ridl.
//You can custom this class, such as override the virtual function in class Mail_Base, but DON'T modify 'Mail_Base.cs'.
using System;
using System.Collections.Generic;
using TreasureBox;
using UnityEngine;

namespace CSharpLike
{
	public class Mail : Mail_Base
	{
		[KissJsonDontSerialize]
		public bool ShowSpot => (wasRead == 0 || (received == 0 && !string.IsNullOrEmpty(appendix)));
		[KissJsonDontSerialize]
		public string SortKey => $"{(ShowSpot?1:0)}{createTime.ToString("yyyy-dd-dd HH:mm:ss")}";
		[KissJsonDontSerialize]
		Dictionary<int, int> mAppendix = null;
		[KissJsonDontSerialize]
		public Dictionary<int,int> Appendix
        {
			get
            {
				if (mAppendix == null)
					mAppendix = Global.StringToDictionary(appendix);
				return mAppendix;
            }
        }
	}
}
