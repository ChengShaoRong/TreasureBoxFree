//It's automatic generate by Account.ridl.
//You can custom this class, such as override the virtual function in class Account_Base, but DON'T modify 'Account_Base.cs'.
using System;
using System.Collections.Generic;
using TreasureBox;
using UnityEngine;

namespace CSharpLike
{
	public class Account : Account_Base
	{
		public enum AccountType
		{
			BuildIn,//Build-in account
			ThirdParty_Test,//Sample for test third party account.
							//Login flow :
							//Client got uid and token from third party SDK. 
							//-> send to our server.
							//-> our server confirm that uid and token from third party server by HTTP(s).
							//-> login success/fail
		}
		#region Event for property value changed
		public override void OnNicknameChanged()
		{
			GetMainScenePanel()?.RefreshNickname();
		}
		public override void OnMoneyChanged()
		{
			GetMainScenePanel()?.RefreshMoney();
		}
		public override void OnDiamondChanged()
		{
			GetMainScenePanel()?.RefreshDiamond();
		}
		public override void OnVpChanged()
		{
			GetMainScenePanel()?.RefreshVP();
		}
		public override void OnLvChanged()
		{
			GetMainScenePanel()?.RefreshLV();
		}
		public override void OnExpChanged()
		{
			GetMainScenePanel()?.RefreshExp();
		}
		public override void OnIconChanged()
		{
			GetMainScenePanel()?.RefreshIcon();
		}
		/// <summary>
		/// Get the main scene panel instance. That make the code shorter and tidy.
		/// </summary>
		MainScenePanel GetMainScenePanel()
        {
			return Global.GetPanel("MainScenePanel") as MainScenePanel;

		}
		#endregion //Event for property value changed
		#region Event for sub system had callback object or delete
		public override void OnCallbackObjectItems(List<Item> data)
		{
			Debug.Log("OnCallbackObjectItems:now all item count = " + items.Count);
		}
		public override void OnCallbackDeleteItems(List<Item> data)
		{
			Debug.Log("OnCallbackDeleteItems:now all item count = " + items.Count);
		}
		public override void OnCallbackObjectMails(List<Mail> data)
		{
			//Refresh mail spot in main scene panel
			GetMainScenePanel()?.RefreshMailSpot();

			//Refresh mail panel
			(Global.GetPanel("MailPanel") as MailPanel)?.OnUpdateOrNewMails(data);
		}
		public override void OnCallbackDeleteMails(List<Mail> data)
		{
			(Global.GetPanel("MailPanel") as MailPanel)?.OnDeleteMails(data);
		}
		public override void OnCallbackObjectSignIn()
		{
			//Refresh mail spot in main scene panel
			GetMainScenePanel()?.RefreshSignInSpot();

			//Refresh sign in panel
			(Global.GetPanel("SignInPanel") as SignInPanel)?.RefreshUI();
		}
		public override void OnCallbackDeleteSignIn()
		{
			Debug.Log("OnCallbackDeleteSignIn:" + signIn.ToString());
		}
		#endregion //Event for sub system had callback object or delete

		/// <summary>
		/// Vip level from vipExp
		/// </summary>
		public int Vip => VipCsv.GetVip(vipExp);

		public List<Mail> SortedMails
		{
            get
			{
				List<Mail> mails = new List<Mail>();
				SortedDictionary<string, Mail> sortedDic = new SortedDictionary<string, Mail>();
				foreach (Mail mail in MySocket.account.mails.Values)
					sortedDic.Add(mail.SortKey + UnityEngine.Random.Range(0f, 1f).ToString("F10"), mail);
				foreach (Mail mail in sortedDic.Values)
					mails.Add(mail);
				mails.Reverse();
				return mails;
			}
		}
	}
}
